package com.zzteck.jumin.webmanager;

import android.content.Context;
import android.os.Handler;

import com.google.gson.Gson;
import com.zzteck.jumin.utils.Constants;

import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * 
 * private static boolean uploadChatRecordSMS(Context context, ChatRecodeSMS recode,
			AsyncHttpResponseHandler responseHandler) {
		JSONObject json_bodies = new JSONObject();
		try {
			json_bodies.put("msg", recode.getMsg());
			json_bodies.put("type", recode.getType());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONObject json_payload = new JSONObject();
		try {
			json_payload.put("bodies", json_bodies);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JSONObject json_recode = new JSONObject();

		AsyncHttpClient client = new HttpRequestClient().getClient();

		try {
			json_recode.put("type", "chatmessage");
			json_recode.put("from", recode.getFrom());
			json_recode.put("to", recode.getTo());
			json_recode.put("msg_id", "" + recode.getTimestamp());
			json_recode.put("timestamp", recode.getTimestamp());
			json_recode.put("chat_type", recode.getChat_type());
			json_recode.put("payload", json_payload);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		StringEntity entity = null;
		try {
			entity = new StringEntity(json_recode.toString(), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		String user_id = EMClient.getInstance().getCurrentUser();
		String url = apiUrl + uploadChatRecodeUrl + user_id;

		client.post(context, url, entity, "application/json", responseHandler);
		return false;
	}
 * 
 * 
 * 
 * */

public class WebHomeManager {

    private static WebHomeManager mInstance;

    private WebManager mWebManager;

    private Context mContext;

    private WebHomeManager(Context context) {
        super ();
        mContext = context;
        mWebManager = WebManager.getInstance ( context );
    }

    public static WebHomeManager getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new WebHomeManager( context );

        }
        return mInstance;
    }


	public void categoryLists(Context context) {


		JSONObject json = new JSONObject();
		try {
			json.put ( "s", "App.Category.Lists" );
			json.put ( "catid", 0 );
		} catch (Exception e) {
			e.printStackTrace();
		}

		RequestBody requestBody = FormBody.create(MediaType.parse("application/json; charset=utf-8"), json.toString());

		Request request = new Request.Builder()
				.url(Constants.HOST)
				.post(requestBody)
				.build();



		Call call = WebManager.getInstance(context).okHttpClient.newCall(request);

		call.enqueue(new Callback() {

			@Override
			public void onFailure(Call call, IOException e) {
				System.out.println("连接失败");
			}
			@Override
			public void onResponse(Call call, Response response) throws IOException {

				String json = response.body().string() ;
				Gson gson = new Gson() ;

				new Handler().post(new Runnable() {
					@Override
					public void run() {
						//tv_message.setText(message);
						//progressBar.setVisibility(View.GONE);
					}
				});
			}

		});
	}

	public void categoryPushcat(Context context) {


		JSONObject json = new JSONObject();
		try {
			json.put ( "s", "App.Category.Pushcat" );
			json.put ( "type", 1 );
		} catch (Exception e) {
			e.printStackTrace();
		}

		RequestBody requestBody = FormBody.create(MediaType.parse("application/json; charset=utf-8"), json.toString());

		Request request = new Request.Builder()
				.url(Constants.HOST)
				.post(requestBody)
				.build();



		Call call = WebManager.getInstance(context).okHttpClient.newCall(request);

		call.enqueue(new Callback() {

			@Override
			public void onFailure(Call call, IOException e) {
				System.out.println("连接失败");
			}
			@Override
			public void onResponse(Call call, Response response) throws IOException {

				String json = response.body().string() ;
				Gson gson = new Gson() ;

				new Handler().post(new Runnable() {
					@Override
					public void run() {
						//tv_message.setText(message);
						//progressBar.setVisibility(View.GONE);
					}
				});
			}

		});
	}


	public void cityIndex(Context context) {


		JSONObject json = new JSONObject();
		try {
			json.put ( "s", "App.City.Index" );
		} catch (Exception e) {
			e.printStackTrace();
		}

		RequestBody requestBody = FormBody.create(MediaType.parse("application/json; charset=utf-8"), json.toString());

		Request request = new Request.Builder()
				.url(Constants.HOST)
				.post(requestBody)
				.build();



		Call call = WebManager.getInstance(context).okHttpClient.newCall(request);

		call.enqueue(new Callback() {

			@Override
			public void onFailure(Call call, IOException e) {
				System.out.println("连接失败");
			}
			@Override
			public void onResponse(Call call, Response response) throws IOException {

				String json = response.body().string() ;
				Gson gson = new Gson() ;

				new Handler().post(new Runnable() {
					@Override
					public void run() {
						//tv_message.setText(message);
						//progressBar.setVisibility(View.GONE);
					}
				});
			}

		});
	}

	public void banner(Context context,String cityId) {


		JSONObject json = new JSONObject();
		try {
			json.put ( "s", "App.Index.Banner" );
		} catch (Exception e) {
			e.printStackTrace();
		}

		RequestBody requestBody = FormBody.create(MediaType.parse("application/json; charset=utf-8"), json.toString());

		Request request = new Request.Builder()
				.url(Constants.HOST)
				.post(requestBody)
				.build();



		Call call = WebManager.getInstance(context).okHttpClient.newCall(request);

		call.enqueue(new Callback() {

			@Override
			public void onFailure(Call call, IOException e) {
				System.out.println("连接失败");
			}
			@Override
			public void onResponse(Call call, Response response) throws IOException {

				String json = response.body().string() ;
				Gson gson = new Gson() ;

				new Handler().post(new Runnable() {
					@Override
					public void run() {
						//tv_message.setText(message);
						//progressBar.setVisibility(View.GONE);
					}
				});
			}

		});
	}

	public void getInfos(Context context,String cityId) {


		JSONObject json = new JSONObject();
		try {
			json.put ( "s", "App.Info.Getinfos" );
			json.put ( "catid", "0" );
			json.put ( "cityid", cityId);
			json.put ( "pages", 1 );
		} catch (Exception e) {
			e.printStackTrace();
		}

		RequestBody requestBody = FormBody.create(MediaType.parse("application/json; charset=utf-8"), json.toString());

		Request request = new Request.Builder()
				.url(Constants.HOST)
				.post(requestBody)
				.build();



		Call call = WebManager.getInstance(context).okHttpClient.newCall(request);

		call.enqueue(new Callback() {

			@Override
			public void onFailure(Call call, IOException e) {
				System.out.println("连接失败");
			}
			@Override
			public void onResponse(Call call, Response response) throws IOException {

				String json = response.body().string() ;
				Gson gson = new Gson() ;

				new Handler().post(new Runnable() {
					@Override
					public void run() {
						//tv_message.setText(message);
						//progressBar.setVisibility(View.GONE);
					}
				});
			}

		});
	}

	public void getVideoInfo(Context context,String cityId) {


		JSONObject json = new JSONObject();
		try {
			json.put ( "s", "App.Info.Getvideoinfo" );
			json.put ( "cityid", cityId);
		} catch (Exception e) {
			e.printStackTrace();
		}

		RequestBody requestBody = FormBody.create(MediaType.parse("application/json; charset=utf-8"), json.toString());

		Request request = new Request.Builder()
				.url(Constants.HOST)
				.post(requestBody)
				.build();



		Call call = WebManager.getInstance(context).okHttpClient.newCall(request);

		call.enqueue(new Callback() {

			@Override
			public void onFailure(Call call, IOException e) {
				System.out.println("连接失败");
			}
			@Override
			public void onResponse(Call call, Response response) throws IOException {

				String json = response.body().string() ;
				Gson gson = new Gson() ;

				new Handler().post(new Runnable() {
					@Override
					public void run() {
						//tv_message.setText(message);
						//progressBar.setVisibility(View.GONE);
					}
				});
			}

		});
	}

}
