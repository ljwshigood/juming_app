/**
 * 项目名称：PublcNumbe
 * r
 * 文件名：WebManager.java
 * 2015-1-12-下午12:00:47
 * 2015 万家恒通公司-版权所有
 *
 * @version 1.0.0
 */
package com.zzteck.jumin.webmanager;

import android.content.Context;
import android.text.TextUtils;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


/**
 * author : liujw
 * modify : 2015-1-12 下午12:00:47
 */
public class WebManager {

    private static WebManager mInstance;

    private Context mContext;

    public OkHttpClient okHttpClient ;

    private WebManager(final Context context) {
        super();


        okHttpClient  = new OkHttpClient.Builder().addInterceptor(new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {
                String token = "";
                if(!TextUtils.isEmpty(token)){
                    Request request = chain.request()
                            .newBuilder()
                            .addHeader("Dljapp-User-Token",token).build() ;
                    return chain.proceed(request);
                }else{
                    Request request = chain.request()
                            .newBuilder()
                            .build() ;
                    return chain.proceed(request);
                }
            }
        })
                .connectTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10,TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build()
                ;


    }

    public synchronized static WebManager getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new WebManager(context);
        }
        return mInstance;
    }

}
